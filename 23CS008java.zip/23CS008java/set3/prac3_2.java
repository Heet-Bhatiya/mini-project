import java.util.*;

class area
{
    private
    int height;
    int base;
    public
    area()
    {
        this.height=5;
        this.base=5;
    }
    area(int r)
    {
        System.out.println(3.14*r*r);
    }
    area(int x,int y)
    {
        System.out.println(.5*x*y);
    }
    void display()
    {
        System.out.println(height+base);
    }
}
public class prac3_2 {
    public static void main(String[] args)
    {
        
        new area();
        new area(5);
        new area(5,5);
        System.out.print("23CS008_Heet Bhatiya");
    }
    
}