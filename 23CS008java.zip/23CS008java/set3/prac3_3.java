import java.util.Scanner;
public class prac3_3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Employee e1=new Employee();
        System.out.println("Enter the First name:");
        e1.setfname();
        System.out.println("Enter the Lirst name:");
        e1.setlname();
        System.out.println("Enter the Salary:");
        e1.setsalary();
        System.out.println("First name :");
        e1.getfname();
        System.out.println("Lirst name :");
        e1.getlname();
        System.out.println("Salary :");
        e1.getsalary();
        e1.getyearsalary();
        System.out.println("promotion:");
        e1.getraise();
        System.out.print("23CS008_Heet Bhatiya");
    }
}
class Employee
{
    String fname;
    String lname;
    double salary;
    Scanner sc=new Scanner(System.in);
    public void setfname()
    {
        fname=sc.nextLine();
    }
    public void setlname()
    {   
        lname=sc.nextLine();
    }
    public void setsalary()
    {
        salary=sc.nextDouble();
    }
    public void getfname()
    {
        System.out.println("First Name :"+fname);
    }
    public void getlname()
    {
        System.out.println("Last Name :"+lname);
    }
    public void getsalary()
    {
        if(salary<0)
        System.out.println("0.0");
        else
        System.out.println("Salary :"+salary);
    }
    public void getyearsalary()
    {
        System.out.println("Yearly Salary :"+salary*12);
    }
    public void getraise()
    {
        System.out.println("salary after promotion :");
        System.out.println("monthly salary :"+salary*(1+(0.1)));
        System.out.print("yearly salary :"+salary*(1+(0.1))*12);
    }
    
}