import java.util.*;

public class prac11 {
    public static void main(String[] args)
    {
        int gdb = Integer.parseInt(args[0]);
        int inr = gdb*100;
        System.out.println(inr);
        System.out.print("23CS008_Heet Bhatiya");
    }
}