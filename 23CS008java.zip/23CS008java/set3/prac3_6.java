public class prac3_6 {
    
    public static void main(String[] args) {
        complex c1 = new complex(1, 2); 
        complex c2 = new complex(3, 4); 
        
        complex c3 = c1.add(c1, c2);   
        
        
        System.out.println("Sum: " + c3.real + " + " + c3.imaginary + "i");
        System.out.print("23CS008_Heet Bhatiya");
    }
}

class complex {
    int real, imaginary;
    
    complex(int real, int imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }
    
    complex add(complex c) {
        complex result = new complex(this.real + c.real, this.imaginary + c.imaginary);
        return result;
    }
}
