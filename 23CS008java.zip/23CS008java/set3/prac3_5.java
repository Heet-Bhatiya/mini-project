import java.util.Scanner;

public class prac3_5 {
    public static void main(String[] args) {    
    
        
        Scanner sc=new Scanner(System.in);
        System.out.println("enter length :");
        int a=sc.nextInt();
        System.out.println("enter breadth :");
        int b=sc.nextInt();
        Area ob1=new Area(a,b);
        System.out.print("23CS008_Heet Bhatiya");
    }
    
}
class Area
{
    Area(int x,int y)
    {
        System.out.println("Area of Rectangle is "+(x*y));
    }
}