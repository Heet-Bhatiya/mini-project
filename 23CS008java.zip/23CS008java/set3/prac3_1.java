import java.util.*;

public class prac3_1 {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(args[0]);
        int x=sc.nextInt();
        System.out.println(x*100);
        System.out.println("23CS008-Heet Bhatiya");
    }
    
}