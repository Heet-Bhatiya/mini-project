import java.util.*;
public class prac3_4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Employee e1=new Employee();
        System.out.print("Enter the First name:");
        e1.setfname();
        System.out.print("Enter the Lirst name:");
        e1.setlname();
        System.out.print("Enter the Salary:");
        e1.setsalary();
        System.out.print("First name :");
        e1.getfname();
        System.out.print("Lirst name :");
        e1.getlname();
        System.out.print("Salary :");
        e1.getsalary();
        System.out.print("23CS008_Heet Bhatiya");
    }
}
class Employee
{
    String fname;
    String lname;
    double salary;
    Scanner sc=new Scanner(System.in);
    public void setfname()
    {
        fname=sc.nextLine();
    }
    public void setlname()
    {   
        lname=sc.nextLine();
    }
    public void setsalary()
    {
        salary=sc.nextDouble();
    }
    public void getfname()
    {
        System.out.println("First Name :"+fname);
    }
    public void getlname()
    {
        System.out.println("Last Name :"+lname);
    }
    public void getsalary()
    {
        if(salary<0)
        System.out.println("0.0");
        else
        System.out.println("Salary :"+salary);
    }
    
    
}