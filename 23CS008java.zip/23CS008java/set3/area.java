import java.util.*;

public class area
{
    area()
    {

    }
    area(int r)
    {
        System.out.println(3.14*r*r);
    }
    area(int x,int y)
    {
        System.out.println(.5*x*y);
    }
}
public class prac2 {
    public static void main(String[] args)
    {
        
        new area();
        new area(5);
        new area(5,5);
    }
}