import java.io.FileInputStream;
import java.io.FileOutputStream;

public class prac8_1
{
    public static void main(String[] args) {
        try {
            FileInputStream fin=new FileInputStream("C:\\Users\\Administrator\\Desktop\\h.txt");
            int i=fin.read();
            System.out.println((char)i);
            System.out.println(i);
            fin.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}