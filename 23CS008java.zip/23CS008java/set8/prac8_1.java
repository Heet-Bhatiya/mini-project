import java.io.File;
import java.util.Scanner;

public class prac8_1 {
    public static void main(String[] args) {
        for(int x=0;x<args.length;x++)
        {
            int y=0;
            try {
                File fileobj=new File(args[x]);
                if(fileobj.exists())
                {
                    System.out.println("searching for file"+args[x]);
                    System.out.println(args[x]+"found");
                    Scanner sc=new Scanner(fileobj);
                    while (sc.hasNextLine()) {
                        y++;
                        sc.nextLine();
                    }
                    System.out.println("there are"+y+"lines in the"+args[x]+"file");
                    sc.close();
                }
                else{
                    System.out.println("file"+args[x]+"does not exist");
                }
            } catch (Exception e) {
                System.out.println("Error occurred while finding this "+args[x]+"file");
            }
        }
    }
}
