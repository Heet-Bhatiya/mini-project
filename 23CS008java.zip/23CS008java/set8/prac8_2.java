import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class prac8_2 {
    public static void main(String[] args)
    {
        if(args.length<1)
        {

        }
        File f=new File("C:\\Users\\Administrator\\Desktop\\h.txt");
        int count=0;
        try(FileReader fr=new FileReader(f));
        BufferedReader br=new BufferedReader(fr) {
            int i=0;
            while((i=br.read())!=-1)
            {
                if(i==args[0].charAt(0))
                {
                    count++;
                }
            }
            System.out.println("the given letter"+are[0].charAt(0)+"occurs"+count+"times");
        } catch (FileNotFoundException e) {
           System.out.println("'h.txt'not found");
        }
        catch(IOException e)
        {
            System.out.println("error");
        }
    }
}
