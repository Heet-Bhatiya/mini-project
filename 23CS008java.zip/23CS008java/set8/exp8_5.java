import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
public class exp8_5 {
        public static void main(String[] args) {
            try {
                FileInputStream fin=new FileInputStream("C:\\Users\\Administrator\\Desktop\\h.txt");
                BufferedInputStream bin=new BufferedInputStream(fin);
                int i=0;
                while((i=fin.read())!=-1)
                {
                    System.out.println((char)i);
                }
                bin.close();
                fin.close();
                System.out.println("success");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
}
