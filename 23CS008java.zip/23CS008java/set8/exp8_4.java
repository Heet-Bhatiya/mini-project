import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class exp8_4 {
        public static void main(String[] args) {
            try {
                FileOutputStream fout=new FileOutputStream("C:\\Users\\Administrator\\Desktop\\h.txt");
                BufferedOutputStream bout=new BufferedOutputStream(fout);
                String s="Hello,World!";
                byte b[]=s.getBytes();
                bout.write(b);
                bout.flush();
                bout.close();
                fout.close();
                System.out.println("success");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
}
