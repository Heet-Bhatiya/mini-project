class testsleep extends Thread{
    public void run(){
        for(int i=0;i<5;i++)
        {
            try{Thread.sleep(500);}
            catch(InterruptedException e){System.out.println(e);}
            System.out.println(i);
        }
    }
}
public class exp3 {
    public static void main(String args[]){
        testsleep t1=new testsleep();
        t1.start();
        testsleep t2=new testsleep();
        t2.start();
    }
}

