#include <iostream>
#include <stack>
#include <string>
#include <cctype>
#include <sstream>

