class MyThread extends Thread{
    public void run(){
        for(int i=0;i<2;i++)
        {
            System.out.println("0-arg");
        }
    }
    public void run(int a){
        for(int i=0;i<a;i++)
        {
            System.out.println("1-arg");
        }
    }
}
public class exp4 {
    public static void main(String []args){
        MyThread t1=new MyThread();
        t1.start();
        MyThread t2=new MyThread();
        t2.run(2);
    }
}

