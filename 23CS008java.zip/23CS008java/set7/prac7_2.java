import java.util.Scanner;
class MyThread extends Thread{
    public void run(int a[],int n,int t){
        int sum=0;
        for(int i=1;i<t;i++)
        {
            a[i]=n/t;
            sum=sum+a[i];
        }
        a[t]=n-sum;
        for(int i=1;i<=t;i++)
        {
            System.out.println(a[i]);
        }
    }
}
public class prac7_2 {
    public static void main(String args[]){
        int[] a=new int[100];
        Scanner z=new Scanner(System.in);
        System.out.println("enter number");
        int n=z.nextInt();
        System.out.println("enter thread");
        int t=z.nextInt();
        MyThread t1=new MyThread();
        t1.run(a,n,t);
    }
 }

