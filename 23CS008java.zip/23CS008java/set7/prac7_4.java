class testsleep extends Thread{
    public void run(){
        for(int i=0;i<5;i++)
        {
            try{Thread.sleep(1000);}
            catch(InterruptedException e){System.out.println(e);}
            System.out.println(i);
        }
    }
}
public class prac7_4 {
    public static void main(String args[]){
        testsleep t1=new testsleep();
        t1.start();
    }
}

