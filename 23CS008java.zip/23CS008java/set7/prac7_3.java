class multi extends Thread{
    public void run(){
        int num=(int)(Math.random() * 100);
        if(num%2==0)
        {
            System.out.println(num+" is Even");
            square t2=new square();
            t2.run(num);
        }
        else
        {
            System.out.println(num+" is Odd");
            cube t2=new cube();
            t2.run(num);
        }
    }
}
class square extends Thread
{
    public void run(int num)
    {
        System.out.println("square of number is"+num*num);
    }
}
class cube extends Thread
{
    public void run(int num)
    {
        System.out.println("cube of number is"+num*num*num);
    }
}
public class prac7_3{
public static void main(String args[]){
    multi t1=new multi();
    t1.start();
}
}