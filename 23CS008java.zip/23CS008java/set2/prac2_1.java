import java.util.*;

public class prac2_1 {
    public static void main(String[] args)
    {
        String Str ="java";
        Scanner sc=new Scanner(System.in);
        System.out.print("enter the number :");
        int n=sc.nextInt();
        for(int i=1;i<=n;i++)
        {
            System.out.println(Str.substring(0,3));
        }
    
    }
}
