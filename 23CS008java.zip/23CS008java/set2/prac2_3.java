import java.util.*;

public class prac2_3 {
    public static void main(String[] args)
    {
        int a[]={1,2,9,4,5};
        String str=Arrays.toString(a);
        System.out.println(str);
        int n=a.length;
        boolean found = true;
        for(int i=0;i<n-1;i++)
        {
            if(a[i]==9)
            {
                found = false;
                break;
            }
        }
        System.out.println(found? "false" : "true");
    }
}