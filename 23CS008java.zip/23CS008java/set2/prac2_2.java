import java.util.*;

public class prac2_2 {
    public static void main(String[] args)
    {
        int a[]={1,2,9,3,3,9,5,6,7};
        int cnt=0;
        int n = a.length;
        for(int i=0;i<n;i++)
        {
            if(a[i] == 9)
            {
                cnt++;
            }
        }
        System.out.println(cnt);
    
    }
}
