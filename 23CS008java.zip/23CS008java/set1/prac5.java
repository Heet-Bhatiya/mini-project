import java.util.*;

public class prac5 {
    public static void main(String[] args) {
        int price[] = {100, 200, 300, 400, 500};
        double gst[] = {.08,.12,.05,.075,.03};
        int a;

        Scanner sc = new Scanner(System.in);
            System.out.println("press 1 for motor");
            System.out.println("press 2 for fan");
            System.out.println("press 3 for tube");
            System.out.println("press 4 for wire");
            System.out.println("press 5 for other");
            System.out.println("Enter your choice");
            a = sc.nextInt();

            float x = (float) (price[a - 1] * gst[a - 1]) + price[a - 1];

            switch (a) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    System.out.println("The total cost is: " + x);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println("this practical made by 23CS008-Heet Bhatiya");
    }
}