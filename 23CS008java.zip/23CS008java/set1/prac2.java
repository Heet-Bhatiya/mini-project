import java.util.*;
public class prac2 {
    public static void main(String[] args)
    {
      
        Scanner s = new Scanner(System.in);
        int a=s.nextInt();
    
        int b=s.nextInt();
        int sum = a+b;
        System.out.print(sum);
        System.out.println("this practical made by 23CS008-Heet Bhatiya");
    }
    
}
