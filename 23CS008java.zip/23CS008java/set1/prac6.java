import java.util.*;
public class prac6 {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("enter the number :");
        int n=sc.nextInt();
        int remainder;
        int reverse=0;
        while (n != 0) 
        {
            remainder = n % 10;
            reverse = reverse * 10 + remainder;
            n /= 10;
          }
        System.out.println("reverse number is :"+reverse);
        System.out.println("this practical made by 23CS008-Heet Bhatiya");
    }
    
}
