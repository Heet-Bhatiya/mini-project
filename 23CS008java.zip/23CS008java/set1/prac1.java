public class prac1 {
    public static void main(String[] args)
    {
        int a=10;
        System.out.println(a+"is the value of a");
        System.out.println("this practical made by 23CS008-Heet Bhatiya");
    }
}
