import java.util.*;
public class prac3 {
    public static void main(String[] args)
    {
      
        double d=1234.5678;
        long x=(long)d;
        int y=(int) ((d-x)*10000);
        System.out.print(x+"."+y);
        System.out.println("this practical made by 23CS008-Heet Bhatiya");
    }
    
}
