import java.util.*;
public class prac4 {
    public static void main(String[] args)
    {
      
        
        int a[][]={{1},{1,2},{1,2,3}};
        System.out.println(a[0].length);
        System.out.println(a[1].length);
        System.out.print(a[2].length);
        System.out.println("this practical made by 23CS008-Heet Bhatiya");
    }
    
}
