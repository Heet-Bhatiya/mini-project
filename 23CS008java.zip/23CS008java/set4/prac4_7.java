public class prac4_7 {
    
    public static void main(String[] args) {
        circle circle=new circle(5, "red");
        rectangle rectangle=new rectangle(5, 5,"blue");
        sigh s1=new sigh(rectangle, "hi");
        sigh s2=new sigh(circle, "hello");
        s1.display();
        s2.display();
    }
}
interface shape
{
    String getcolor();
    double area();
}
class rectangle implements shape
{
    double length;
    double width;
    String color;
    public
    rectangle(double length,double width,String color)
    {
        this.length=length;
        this.width=width;
        this.color=color;
    }
    public String getcolor()
    {
       return color;
    }
    public double area()
    {
        return 3.14*length*width;
    }
}
class circle implements shape
{
    double radius;
    String color;
    public
    circle(double radius,String color)
    {
        this.radius=radius;
        this.color=color;
    }
    public String getcolor()
    {
        return color;
    }
    public double area()
    {
        return 3.14*radius*radius;
    }
}
class sigh
{
    shape shape;
    String text;
    public sigh(shape s,String t)
    {
        shape=s;
        text=t;
    }
    public void display()
    {
        System.out.println(shape.getcolor());
        System.out.println(text);
        System.out.println(shape.area());
    }
}
