public class prac4_6 {
    public static void main(String[] args) {
        Q ob1=new Q();
        ob1.displayp1();
        ob1.displayp2();
        ob1.displayp12();
    }
}
interface P1
{
    int p1=10;
    void displayp1();
}
interface P2
{
    int p2=20;
    void displayp2();
}
interface P12 extends P1,P2
{
    int p12=30;
    void displayp12();
}
class Q implements P12
{
    public void displayp1()
    {
        System.out.println(p1);
    }
    public void displayp2()
    {
        System.out.println(p2);
    }
    public void displayp12()
    {
        System.out.println(p12);
    }
}