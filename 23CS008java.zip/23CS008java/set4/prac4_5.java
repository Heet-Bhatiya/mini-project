public class prac4_5 {
    public static void main(String[] args) {
        Undergraduate ob2=new Undergraduate();
        ob2.getDegree();
        postgraduate ob3=new postgraduate();
        ob3.getDegree();
    }
}
class Degree
{
    public
    void getDegree()
    {
        System.out.println("I got a degree");
    }
}
class Undergraduate extends Degree
{
    public
    void getDegree()
    {
        super.getDegree();
        System.out.println("I am an Undergraduate");
    }

}
class postgraduate extends Degree
{
    public
    void getDegree()
    {
        super.getDegree();
        System.out.println("I am an postgraduate");
    }

}
