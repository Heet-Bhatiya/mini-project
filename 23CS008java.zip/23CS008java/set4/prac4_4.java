public class prac4_4 {

    public static void main(String[] args) {
        B ob = new B();
        ob.display();
        
    }
    
}
class A
{
    static int x=5;
    public void display()
    {
        System.out.println(x);
        
    }

}
class B extends A
{
    int x=10;
    public void display()
    {
        System.out.println("class B"+x);
        System.out.println("class A"+super.x);
    }
}