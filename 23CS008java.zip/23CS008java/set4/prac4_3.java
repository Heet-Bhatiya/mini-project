import java.util.Scanner;

public class prac4_3 {
    public static void main(String[] args) {
        rectangle ob1 = new rectangle(5,6);
        ob1.area();
        ob1.perimeter();
        square ob2 = new square(5);
        ob2.area();
        ob2.perimeter();
        Scanner sc = new Scanner(System.in);
        square[] ob3=new square[10];
        for(int i=0;i<10;i++)
        {
            int side=sc.nextInt();
            ob3[i]=new square(side);
        }
        for(int i=0;i<10;i++)
        {
            ob3[i].area();
            ob3[i].perimeter();
        }
        System.out.println("23CS008_Heet Bhatiya");
    }
}
class rectangle
{
    int length;
    int breadth;
    public
    rectangle(int l,int b)
    {
        length=l;
        breadth=b;
    }
    void area()
    {
        System.out.println(length*breadth);
    }
    void perimeter()
    {
        System.out.println(2*(length+breadth));
    }
}
class square extends rectangle {

    public
    square(int s)
    {
        super(s,s);
    }

}