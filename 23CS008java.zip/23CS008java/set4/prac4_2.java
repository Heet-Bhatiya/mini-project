import java.util.Scanner;

public class prac4_2 {
    public static void main(String[] args) {
        employee e1 = new employee();
        e1.getdata();
        e1.printdata();
        System.out.println("23CS008_Heet Bhatiya");
    }
}

class member {
    String name;
    int age;
    String address;
    long phone;
    int salary;
    
}

class employee extends member {
    Scanner sc = new Scanner(System.in);
    String specialization;

    public void getdata() {
        System.out.print("Enter the name: ");
        name = sc.nextLine();
        System.out.print("Enter the age: ");
        age = sc.nextInt();
        sc.nextLine(); // Consume newline left-over
        System.out.print("Enter the address: ");
        address = sc.nextLine();
        System.out.print("Enter the phone number: ");
        phone = sc.nextLong();
        System.out.print("Enter the salary: ");
        salary = sc.nextInt();
        sc.nextLine(); // Consume newline left-over
        System.out.print("Enter the specialization: ");
        specialization = sc.nextLine();
    }

    public void printdata() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("Salary: " + salary);
        System.out.println("Specialization: " + specialization);
    }
}

class manager extends member {
    Scanner sc = new Scanner(System.in);
    String department;

    public void getdata() {
        System.out.print("Enter the name: ");
        name = sc.nextLine();
        System.out.print("Enter the age: ");
        age = sc.nextInt();
        sc.nextLine(); // Consume newline left-over
        System.out.print("Enter the address: ");
        address = sc.nextLine();
        System.out.print("Enter the phone number: ");
        phone = sc.nextLong();
        System.out.print("Enter the salary: ");
        salary = sc.nextInt();
        sc.nextLine(); // Consume newline left-over
        System.out.print("Enter the department: ");
        department = sc.nextLine();
    }

    public void printdata() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("Salary: " + salary);
        System.out.println("Department: " + department);
    }
}
