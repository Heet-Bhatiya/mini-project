public class prac4_1 {
    public static void main(String[] args) {    

        A ob1=new A();
        ob1.getdata();
        B ob2=new B();
        ob2.getdata();
        ob2.getdata1();
        System.out.println("23CS008_Heet Bhatiya");
    }   
}
class A
{
    public void getdata()
    {
        System.out.println("this is parent class");
    }
}
class B extends A
{   
    public void getdata1()
    {   
        System.out.println("this is child class");
     }
}
